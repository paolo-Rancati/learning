/**
 * cse250.pa2.SortedList.scala
 *
 * Copyright 2020 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 * Submission author
 * UBIT: arflierl
 * Person#: 31245340
 *
 * Collaborators (include UBIT name of each, comma separated):
 * UBIT:
 */
package cse250.pa2

import cse250.list.{EmptyList, ListNode}

class SortedList[A] (implicit _comp: Ordering[A]) extends collection.Seq[A] {
  // Updates the toString to mention our class name instead of Seq.
  override protected[this] def className = "SortedList"

  // Use _storageList to maintain the sorted list.
  var _storageList: cse250.list.ImmutableLinkedList[A] = cse250.list.EmptyList
  // ---------- MAKE CHANGES BELOW ----------

  /** Gets element at position i within the list. */
  override def apply(i: Int): A = {
    if (_storageList.isEmpty || i > (_storageList.length - 1)) {
      throw new IllegalArgumentException("index out of bounds")
    } else _storageList.apply(i)
  }

  /** Gets the number of elements stored within the list. */
  override def length: Int = _storageList.length

  /** Returns an Iterator that can be used only once. */
  override def iterator: Iterator[A] = _storageList.iterator

  /**
   * Inserts one copy of elem into the list in non-decreasing order.
   * @param elem element to be inserted.
   */
  def insert(elem: A): Unit = {
    if (_storageList.isEmpty) { //emptyList
      _storageList = _storageList.inserted(0, elem)
      return
    }
    var check = _storageList
    if (check.tail.isEmpty) { //one entry in the list
      if (_comp.gt(elem, _storageList.head)) {
        _storageList = _storageList.inserted(1, elem)
      } else {
        _storageList = _storageList.inserted(0, elem)
      }
    } else { //more than one entry in the list
      var insertTo = 0
      while (!check.tail.isEmpty) { //while there is more than one element
        if (_comp.gt(elem, check.head)) insertTo += 1
        check = check.tail
      }
      if (_comp.gt(elem, check.head)) insertTo += 1  //check with the last element
      _storageList = _storageList.inserted(insertTo, elem)
    }
  }


  /**
   * Removes all copies of elem from the list.
   * @param elem element to be removed.
   * @return true if any change has been made, and false otherwise.
   */
  def remove(elem: A): Boolean = {
    var retval = false
    var rangeStart = 0
    var rangeEnd = 0
    for (i <- _storageList.iterator) {

    }
    retval
  }

  /** Takes in a queue of valid operations to perform. Each pair has the form:
   *      (OP,elem)
   *  where:
   *      OP will be the string "insert" or "remove"
   *      elem will be a value of type A to use as the argument to OP. */
  def processBatch(operations: cse250.types.mutable.QueueADT[(String,A)]): Unit = ???

  /** Undo the last modification, if any change has been made.
   * If no change to undo exists, throw an IllegalArgumentException.
   */
  def undoLastModification(): Unit = ???
}
