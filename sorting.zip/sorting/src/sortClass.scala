class sortClass (val unsorted: Seq[Int]) {

  def cheat(): Array[Int] = {
    unsorted.sorted.toArray
  }

}
