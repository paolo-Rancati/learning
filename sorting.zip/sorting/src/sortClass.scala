import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

class sortClass (val unsorted: Seq[Int]) { //is there a way to make this valid for ALL numeric types?

  def cheat(): Array[Int] = {
    unsorted.sorted.toArray
  }

  def targetExists(target: Int): Boolean = {
    val differenceArray = ArrayBuffer[Int]()
    for (i <- 0 until unsorted.length) {
      val difference = target - unsorted(i)
      if (unsorted.contains(difference)) {
        println("target acquired")
        return true
      }
    }
    println("no pairs of elements exists which sum to the desired target value")
    false
  }

  def returnTargetIndices(target: Int): Any = { //Don't think return type of Any is good, but it works for now
    var differenceIndex = new mutable.HashMap[Int, Int]()
    for (i <- 0 until unsorted.length) {
      if (differenceIndex.keysIterator.toArray.contains(unsorted(i))) {
        return (differenceIndex(unsorted(i)), i)
      }
      val difference = target - unsorted(i)
      differenceIndex += (difference -> i)
    }
    false //not sure how to restrict return type to (Int, Int) but alert user that no pairs which sum to target exist
  }

}
