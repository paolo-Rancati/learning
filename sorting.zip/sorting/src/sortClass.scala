
class sortClass (val unsorted: Seq[Int]) { //is there a way to make this valid for ALL numeric types?

  def cheat(): Array[Int] = {
    unsorted.sorted.toArray
  }

}
