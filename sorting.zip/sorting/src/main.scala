

object Main {
  def main(args: Array[String]): Unit = {
    //val dirty = for (i <- 1 to 1000) yield scala.util.Random.nextInt(500)
    val dirty = Seq[Int](2,3,40,11, 89, -10,2, 345)
    val sort = new sortClass(dirty)
    val check = sort.cheat()
    sort.targetExists(2001)
    sort.targetExists(43)
    println(sort.returnTargetIndices(2001))
    println(sort.returnTargetIndices(335))
  }

}