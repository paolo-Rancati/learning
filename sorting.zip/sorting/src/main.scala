

object Main {
  def main(args: Array[String]): Unit = {
    val dirty = for (i <- 1 to 1000) yield scala.util.Random.nextInt(500)
    println(dirty.mkString(" "))
    val sort = new sortClass(dirty)
    val check = sort.cheat()
    println(check.mkString(" "))
  }
}