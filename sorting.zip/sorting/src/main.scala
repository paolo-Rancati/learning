

object Main {
  def main(args: Array[String]): Unit = {
    //val dirty = for (i <- 1 to 1000) yield scala.util.Random.nextInt(500)
    val dirty = Seq[Int](2,3,40,11, 89, -10,2, 345)
    val sort = new sortClass(dirty)
    val check = sort.cheat()
    val targetCheck = sort.targetExists(2001)
    if (targetCheck) {
      println("target acquired")
    }else println("target unavailable")
    val targetIndices = sort.returnTargetIndices(100)
    println(targetIndices)
  }

}