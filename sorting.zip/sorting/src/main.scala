

object Main {
  def main(args: Array[String]): Unit = {
    val dirty = for (i <- 1 to 1000) yield scala.util.Random.nextInt(500)
    //println(dirty)
    val sorted = new sortClass(dirty)
    //println(sorted.cheat().toList)
  }
}