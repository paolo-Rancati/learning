import scala.collection.mutable

class targetFinder (val search: Seq[Int]) {

  def targetExists(target: Int): Boolean = {
    for (i <- search.indices) {
      val difference = target - search(i)
      if (search.contains(difference)) {
        println("target acquired")
        return true
      }
    }
    println("no pairs of elements exists which sum to the desired target value")
    false
  }

  def returnTargetIndices(target: Int): Any = { //Don't think return type of Any is good, but it works for now
    var differenceIndex = new mutable.HashMap[Int, Int]()
    for (i <- search.indices) {
      if (differenceIndex.keysIterator.toArray.contains(search(i))) {
        return (differenceIndex(search(i)), i)
      }
      val difference = target - search(i)
      differenceIndex += (difference -> i)
    }
    false //not sure how to restrict return type to (Int, Int) but alert user that no pairs which sum to target exist
  }


}
