object Main {
  def main(args: Array[String]): Unit = {
    println("default Scala project template with scalatest")
  }
}